﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MovieDataCoreWebAPI.Models
{
    public class Entry
    {
        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("programType")]
        public string ProgramType { get; set; }

        [JsonProperty("images")]
        public Images Images { get; set; }

        [JsonProperty("releaseYear")]
        public int ReleaseYear { get; set; }
    }
}
