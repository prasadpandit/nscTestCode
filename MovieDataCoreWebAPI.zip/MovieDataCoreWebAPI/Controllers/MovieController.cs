﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using MovieDataCoreWebAPI.Models;

namespace MovieDataCoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        [HttpGet]
        public Root Get()
        {
            //var jsonString = System.IO.File.ReadAllText("C:\\sample.json");
            var folderDetails = Path.Combine(Directory.GetCurrentDirectory(), $"wwwroot\\{"MasterData\\sample.json"}");
            var jsonString = System.IO.File.ReadAllText(folderDetails);
            Root items = JsonConvert.DeserializeObject<Root>(jsonString);
            return items;
        }

    }
}
