﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebUI.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace WebUI.Controllers
{
    public class MovieController : Controller
    {
        private const string URL = "http://localhost:55553/";
        private string urlParameters = "api/Movie";

        public IActionResult Index()
        {
            return View();
        }

        public ActionResult DisplayMovieData(string strType,string strTitle, string strSortOrder)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            List<Entry> lstEntry = new List<Entry>();
            Entry objEntry = new Entry();
            Images objImage = new Images();
            PosterArt objPosterArt = new PosterArt();

            HttpResponseMessage response = client.GetAsync(urlParameters).Result;
            if (response.IsSuccessStatusCode)
            {
                var root = response.Content.ReadAsStringAsync();
                var moviesList = root.Result;
                Root rootData = JsonConvert.DeserializeObject<Root>(moviesList);
                lstEntry = rootData.Entries.Take(30).ToList();
                if(!string.IsNullOrEmpty(strType))
                {
                    lstEntry=lstEntry.Where(e => e.ProgramType == strType.ToLower()).ToList();
                    if (!string.IsNullOrEmpty(strTitle))
                    {
                        lstEntry = lstEntry.Where(e => e.Title.Contains(strTitle)).ToList();
                    }
                }
                if(!string.IsNullOrEmpty(strTitle))
                {
                    lstEntry = lstEntry.Where(e => e.Title.Contains(strTitle)).ToList();
                    if (!string.IsNullOrEmpty(strType))
                    {
                        lstEntry = lstEntry.Where(e => e.ProgramType == strType.ToLower()).ToList();
                    }
                }
                if(!string.IsNullOrEmpty(strSortOrder))
                {
                    if (!string.IsNullOrEmpty(strTitle))
                    {
                        lstEntry = lstEntry.Where(e => e.Title.Contains(strTitle)).ToList();
                        if (!string.IsNullOrEmpty(strType))
                        {
                            lstEntry = lstEntry.Where(e => e.ProgramType == strType.ToLower()).ToList();
                        }
                    }

                    if (!string.IsNullOrEmpty(strType))
                    {
                        lstEntry = lstEntry.Where(e => e.ProgramType == strType.ToLower()).ToList();
                        if (!string.IsNullOrEmpty(strTitle))
                        {
                            lstEntry = lstEntry.Where(e => e.Title.Contains(strTitle)).ToList();
                        }
                    }

                    switch (strSortOrder)
                    {
                        case "yeardescending":
                            lstEntry = lstEntry.OrderByDescending(e => e.ReleaseYear).ToList();
                            break;
                        case "yearascending":
                            lstEntry = lstEntry.OrderBy(e => e.ReleaseYear).ToList();
                            break;
                        case "titledescending":
                            lstEntry = lstEntry.OrderByDescending(e => e.Title).ToList();
                            break;
                        case "titleascending":
                            lstEntry = lstEntry.OrderBy(e => e.Title).ToList();
                            break;

                    }
                }
            }
            client.Dispose();
            return PartialView("_parMovieList", lstEntry);
        }

        [HttpGet]
        public List<Entry> GetEntries()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(URL);

            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            List<Entry> lstEntry = new List<Entry>();
            Entry objEntry = new Entry();
            Images objImage = new Images();
            PosterArt objPosterArt = new PosterArt();

            // List data response.
            HttpResponseMessage response = client.GetAsync(urlParameters).Result;
            if (response.IsSuccessStatusCode)
            {
                //var root = response.Content.ReadAsAsync<Root>();
                var root = response.Content.ReadAsStringAsync();
                var moviesList = root.Result;
                Root rootData = JsonConvert.DeserializeObject<Root>(moviesList);
                lstEntry = rootData.Entries.Take(30).ToList();
            }
            else
            {

            }

            client.Dispose();

            return lstEntry;
        }


    }
}
