﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebUI.Models
{
    public class Root
    {
        public int Total { get; set; }
        public List<Entry> Entries { get; set; }
    }
}
