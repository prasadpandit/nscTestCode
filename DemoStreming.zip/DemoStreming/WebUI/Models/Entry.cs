﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebUI.Models;

namespace WebUI.Models
{
    public class Entry
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public string ProgramType { get; set; }
        public Images Images { get; set; }
        public int ReleaseYear { get; set; }
    }
}
